<?php
require "vendor/autoload.php";
require "view/index.view.php";

