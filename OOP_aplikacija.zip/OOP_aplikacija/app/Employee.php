<?php

namespace OOP;

Class Employee extends User{
    private $title;
    private $salary;
    private $educationlevel;
    private $responsibilities = [];

    public function __construct($name,$surname,$email,$address){
        $this->name = $name;
        $this->surname = $surname;
        $this->email = $email;
        $this->address = $address;
    }
    public function addresponsibility($responsibility){
        $this->responsibilities[] = $responsibility;
    }
    public function addtitle($title){
        $this->title = $title;
    }
    public function addsalary($salary){
        $this->salary = $salary;
    }
    public function addeducationlevel($educationlevel){
        $this->educationlevel = $educationlevel;
    }
    public function getInfo()
    {
      return[
          $this->name,
          $this->surname,
          $this->email,
          $this->address,
          $this->title,
          $this->salary,
          $this->educationlevel,
          $this->responsibilities
        ];
    }
   
   }  

