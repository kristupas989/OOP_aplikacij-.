<?php

namespace OOP;

abstract class User{
    protected $name;
    protected $surname;
    protected $email;
    protected $address;

 
    public function getInfo(){}


} 

