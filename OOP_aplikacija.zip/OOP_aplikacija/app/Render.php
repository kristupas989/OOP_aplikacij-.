<?php

namespace OOP;

class Render{

    static public function PrintInfo($data){
        foreach($data as $item) {
            if (!is_array($item))  
               echo $item. "<br>";
         else foreach($item as $value){
             echo $value. "<br>";
         }
        }
    }
}