<?php use OOP\Employee; ?>
<?php use OOP\Render;  ?>
<!Doctype html>
<html lang="lt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>PHP aplikacija</title>
 </head>
 </body>
    <?php 
     $user = new Employee("Andrejus","Maksimovas","nežinomas@nežinomas","namasnežinomas");
     $user->addresponsibility("Programuoti ir kurti žaidimus");
     $user->addtitle("Programuotojas ir žaidimų kūrejas");
     $user->addsalary("alga jo gera");
     $user->addeducationlevel("Aukštasis");
     Render::PrintInfo($user->getInfo()); 
    ?>
 </body>
 </html>
